import math
import os
import mindspore.numpy
from mindspore import context, ParallelMode
from mindspore.communication.management import init
from numpy import mean
import numpy as np
from MFWOA.MFWOA import MFWOA
from MFWOA.benchmark import benchmark  # Import the benchmark function
def main():
    # Calling the solvers
    pop_M = 30  # population size 100
    pop_S = pop_M
    gen = 100  # generation count 500

    p_il = 1  # probability of individual learning (BFGA quasi-Newton Algorithm)
    rmp = 0.3  # random mating probability
    reps = 1  # repetitions 20
    for index in range(1, 10):
        Tasks = benchmark(index)
        data_MFWOA = MFWOA(Tasks, pop_M, gen, rmp, p_il, reps, index)
        task_for_comparison_with_SOO = 1
        data_SOO_1 = WOA(Tasks[task_for_comparison_with_SOO], task_for_comparison_with_SOO, pop_S, gen, p_il, reps)
        task_for_comparison_with_SOO = 2
        data_SOO_2 = WOA(Tasks[task_for_comparison_with_SOO], task_for_comparison_with_SOO, pop_S, gen, p_il, reps)

    # Save the results (uncomment the line below if needed)
    # np.savez('result2.npz', data_MFWOA=data_MFWOA, data_SOO_1=data_SOO_1, data_SOO_2=data_SOO_2)


if __name__ == "__main__":
    main()