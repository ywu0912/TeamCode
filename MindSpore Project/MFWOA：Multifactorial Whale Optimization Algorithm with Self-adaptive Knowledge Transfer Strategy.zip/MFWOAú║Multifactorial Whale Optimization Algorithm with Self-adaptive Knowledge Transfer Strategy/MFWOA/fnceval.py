import numpy as np
from scipy.optimize import minimize

def fnceval(Task, rnvec, p_il, options):
    d = Task.dims
    nvars = rnvec[:d]
    minrange = Task.Lb[:d]
    maxrange = Task.Ub[:d]
    y = maxrange - minrange
    vars = y * nvars + minrange  # decoding

    if np.random.rand() <= p_il:
        result = minimize(Task.fnc, vars, options=options)
        x = result.x
        nvars = (x - minrange) / y
        m_nvars = np.clip(nvars, 0, 1)

        if not np.array_equal(m_nvars, nvars):
            nvars = m_nvars
            x = y * nvars + minrange
            result = minimize(Task.fnc, x, options=options)

        rnvec[:d] = nvars
        objective = result.fun
        funcCount = result.nfev
    else:
        x = vars
        objective = Task.fnc(x)
        funcCount = 1

    return objective, rnvec, funcCount
