import numpy as np


def benchmark(index):
    # BENCHMARK function
    # Input
    # - index: the index number of the problem set

    # Output:
    # - Tasks: benchmark problem set
    # - g1: global optima of Task 1
    # - g2: global optima of Task 2

    switch = {
        1: "CI_H",
        2: "CI_M",
        3: "CI_L",
        4: "PI_H",
        5: "PI_M",
        6: "PI_L",
        7: "NI_H",
        8: "NI_M",
        9: "NI_L"
    }

    selected_case = switch.get(index)

    if selected_case is not None:
        # Load data from the corresponding file
        data = np.load(f'D:/Python38/work/pythonProject/MFWOA/Tasks/{selected_case}.npz', allow_pickle=True)

        dim = 50
        Rotation_Task1 = data['Rotation_Task1']
        GO_Task1 = data['GO_Task1']
        Rotation_Task2 = data['Rotation_Task2']
        GO_Task2 = data['GO_Task2']

        Tasks = []
        g1 = None
        g2 = None

        if index in [1, 2, 3]:
            # Complete intersection cases
            Tasks.append({'dims': dim, 'fnc': lambda x: Griewank(x, Rotation_Task1, GO_Task1),
                          'Lb': -100 * np.ones(dim), 'Ub': 100 * np.ones(dim)})
            Tasks.append({'dims': dim, 'fnc': lambda x: Rastrigin(x, Rotation_Task2, GO_Task2),
                          'Lb': -50 * np.ones(dim), 'Ub': 50 * np.ones(dim)})

            g1 = GO_Task1
            g2 = GO_Task2
        elif index in [4, 5, 6]:
            # Partially intersection cases
            Tasks.append({'dims': dim, 'fnc': lambda x: Rastrigin(x, Rotation_Task1, GO_Task1),
                          'Lb': -50 * np.ones(dim), 'Ub': 50 * np.ones(dim)})
            Tasks.append({'dims': dim, 'fnc': lambda x: Sphere(x, GO_Task2),
                          'Lb': -100 * np.ones(dim), 'Ub': 100 * np.ones(dim)})

            g1 = GO_Task1
            g2 = GO_Task2
        elif index in [7, 8, 9]:
            # No intersection cases
            Tasks.append({'dims': dim, 'fnc': lambda x: Rosenbrock(x),
                          'Lb': -50 * np.ones(dim), 'Ub': 50 * np.ones(dim)})
            Tasks.append({'dims': dim, 'fnc': lambda x: Rastrigin(x, Rotation_Task2, GO_Task2),
                          'Lb': -50 * np.ones(dim), 'Ub': 50 * np.ones(dim)})

            g1 = np.ones(dim)
            g2 = GO_Task2

    return Tasks, g1, g2




def Griewank(var, M, opt):
    dim = len(var)
    var = np.dot(M, (var - opt).reshape(-1, 1)).flatten()  # Matrix multiplication
    sum1 = np.sum(var ** 2)
    sum2 = np.prod(np.cos(var / np.sqrt(np.arange(1, dim + 1))))

    obj = 1 + sum1 / 4000 - sum2
    return obj


def Rastrigin(var, M, opt):
    dim = len(var)
    var = np.dot(M, (var - opt).reshape(-1, 1)).flatten()  # Matrix multiplication
    obj = 10 * dim + np.sum(var**2 - 10 * np.cos(2 * np.pi * var))
    return obj


def Ackley(var, M, opt):
    dim = len(var)
    var = np.dot(M, (var - opt).reshape(-1, 1)).flatten()  # Matrix multiplication
    sum1 = np.sum(var**2)
    sum2 = np.sum(np.cos(2 * np.pi * var))
    avgsum1 = sum1 / dim
    avgsum2 = sum2 / dim
    obj = -20 * np.exp(-0.2 * np.sqrt(avgsum1)) - np.exp(avgsum2) + 20 + np.exp(1)
    return obj


def Schwefel(var):
    dim = len(var)
    summation = np.sum(var * np.sin(np.sqrt(np.abs(var))))
    obj = 418.9829 * dim - summation
    return obj


def Rosenbrock(var):
    dim = len(var)
    summation = 0
    for ii in range(dim - 1):
        xi = var[ii]
        xnext = var[ii + 1]
        new = 100 * (xnext - xi**2)**2 + (xi - 1)**2
        summation += new
    obj = summation
    return obj


def Sphere(var, opt):
    var = var - opt
    obj = np.sum(var**2)
    return obj



def Weierstrass(var, M, opt):
    D = len(var)
    var = np.dot(M, (var - opt).reshape(-1, 1)).flatten()  # Matrix multiplication
    a = 0.5
    b = 3
    kmax = 20
    obj = 0

    for i in range(D):
        for k in range(kmax + 1):
            obj += a**k * np.cos(2 * np.pi * b**k * (var[i] + 0.5))

    for k in range(kmax + 1):
        obj -= D * a**k * np.cos(2 * np.pi * b**k * 0.5)
        
    return obj
