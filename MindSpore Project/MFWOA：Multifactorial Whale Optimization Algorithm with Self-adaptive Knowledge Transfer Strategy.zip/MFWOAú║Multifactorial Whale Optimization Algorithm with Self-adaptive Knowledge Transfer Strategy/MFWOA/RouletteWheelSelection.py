import numpy as np

def roulette_wheel_selection(array_input):
    length = len(array_input)
    # If input is one element, return right away
    if length == 1:
        return 0

    # Normalize the array if it contains values less than 1
    if np.any(array_input < 1):
        if np.min(array_input) != 0:
            array_input = 1 / np.min(array_input) * array_input
        else:
            temp = array_input
            temp[array_input == 0] = np.inf
            array_input = 1 / np.min(temp) * array_input

    temp = 0
    temp_prob = np.zeros(length)

    for i in range(length):
        temp_prob[i] = temp + array_input[i]
        temp = temp_prob[i]

    random_value = np.random.uniform(0, temp_prob[-1])
    index = np.argmax(temp_prob >= random_value)

    return index
