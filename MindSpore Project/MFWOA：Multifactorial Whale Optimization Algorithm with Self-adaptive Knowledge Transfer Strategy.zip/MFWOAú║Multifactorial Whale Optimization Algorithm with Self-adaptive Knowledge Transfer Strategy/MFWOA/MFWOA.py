import numpy as np
from scipy.optimize import minimize
import random
import time
import matplotlib.pyplot as plt

class Chromosome:
    def __init__(self, D):
        self.rnvec = np.zeros(D)
        self.factorial_costs = np.zeros(no_of_tasks)
        self.factorial_ranks = np.zeros(no_of_tasks)
        self.skill_factor = 0
        self.scalar_fitness = 0

def initialize(chromosome, D):
    chromosome.rnvec = np.random.rand(D)
    chromosome.factorial_costs = np.zeros(no_of_tasks)
    chromosome.factorial_ranks = np.zeros(no_of_tasks)
    chromosome.skill_factor = 0
    chromosome.scalar_fitness = 0
    return chromosome

def evaluate(chromosome, Tasks, p_il, no_of_tasks, options):
    for i in range(no_of_tasks):
        result = minimize(Tasks[i].fnc, chromosome.rnvec, options=options)
        chromosome.factorial_costs[i] = result.fun
    return chromosome

def boundary_check(chromosome, D_multitask):
    chromosome.rnvec[chromosome.rnvec > 1] = 1
    chromosome.rnvec[chromosome.rnvec < 0] = 0
    return chromosome

def sort_population(population):
    return sorted(population, key=lambda x: x.factorial_costs[population[i].skill_factor])

def MFWOA(Tasks, pop_M, gen, rmp, p_il, reps, index):
    def random_selection(group, skill_factor):
        group_sf = [ind for ind in group if ind.skill_factor == skill_factor]
        rand_ind = random.choice(group_sf)
        return rand_ind

    clc = lambda: None
    tic = lambda: None
    tic.t = time.time()

    if pop_M % 2 != 0:
        pop_M += 1

    no_of_tasks = len(Tasks)
    if no_of_tasks <= 1:
        raise ValueError('At least 2 tasks required for MFWOA')

    D = [Tasks[i].dims for i in range(no_of_tasks)]
    D_multitask = max(D)

    options = {'Display': 'off', 'Algorithm': 'quasi-newton', 'MaxIter': 2}

    fnceval_calls = np.zeros(reps)
    calls_per_individual = np.zeros(pop_M)
    EvBestFitness = np.zeros((no_of_tasks * reps, gen))
    TotalEvaluations = np.zeros((reps, gen))
    bestobj = np.inf * np.ones(no_of_tasks)
    best_pos = np.zeros((no_of_tasks, D_multitask))

    bestInd_data = np.empty((reps, no_of_tasks), dtype=Chromosome)

    for rep in range(reps):
        print(rep)

        population = [Chromosome(D_multitask) for _ in range(pop_M)]
        for i in range(pop_M):
            population[i] = initialize(population[i], D_multitask)
            population[i].skill_factor = 0

        for i in range(pop_M):
            population[i] = evaluate(population[i], Tasks, p_il, no_of_tasks, options)
            calls_per_individual[i] = 1

        fnceval_calls[rep] += np.sum(calls_per_individual)
        TotalEvaluations[rep, 0] = fnceval_calls[rep]

        factorial_cost = np.zeros(pop_M)
        for i in range(no_of_tasks):
            for j in range(pop_M):
                factorial_cost[j] = population[j].factorial_costs[i]
            sorted_indices = np.argsort(factorial_cost)
            population = [population[sorted_indices[j]] for j in range(pop_M)]
            for j in range(pop_M):
                population[j].factorial_ranks[i] = j
            bestobj[i] = population[0].factorial_costs[i]
            best_pos[i, :] = population[0].rnvec
            bestInd_data[rep, i] = population[0]
            EvBestFitness[i + 2 * (rep - 1), 0] = bestobj[i]

        for i in range(pop_M):
            min_rank_index = np.argmin(population[i].factorial_ranks)
            population[i].skill_factor = min_rank_index
            population[i].scalar_fitness = 1 / (min_rank_index + 1)

        t = 1
        while t <= gen:
            a = 2 - t * (2 / gen)
            a2 = -1 + t * (-1 / gen)

            asf = [j for j in range(pop_M) if population[j].skill_factor == 1]
            bsf = [j for j in range(pop_M) if population[j].skill_factor == 0]

            group = [asf, bsf]

            for i in range(pop_M):
                asf = group[population[i].skill_factor]
                bsf = group[1 - population[i].skill_factor]

                B = random.sample(asf, len(asf))
                C = random.sample(bsf, len(bsf))
                i_rand = B[0]
                j1_rand, j2_rand = C[:2]

                r1, r2 = random.random(), random.random()

                A = 2 * a * r1 - a
                C = 2 * r2

                B = 0.2

                b = 1
                l = (a2 - 1) * random.random() + 1
                p = random.random()

                if random.random() < rmp:
                    for j in range(D_multitask):
                        if p < 0.5:
                            if abs(A) >= 1:
                                D_X_rand = abs(C * population[i_rand].rnvec[j] - population[i].rnvec[j])
                                Other_D = abs(
                                    population[j1_rand].rnvec[j] - population[j2_rand].rnvec[j]
                                )
                                population[i].rnvec[j] = (
                                    population[i_rand].rnvec[j]
                                    - A / 2 * D_X_rand
                                    - A / 2 * Other_D
                                )
                            elif abs(A) < 1:
                                D_Leader = abs(
                                    C * best_pos[population[i].skill_factor, j]
                                    - population[i].rnvec[j]
                                )
                                Other_D = abs(
                                    C * best_pos[1 - population[i].skill_factor, j]
                                    - population[j1_rand].rnvec[j]
                                )
                                population[i].rnvec[j] = (
                                    best_pos[population[i].skill_factor, j]
                                    - A / 2 * D_Leader
                                    - A / 2 * Other_D
                                )
                        elif p >= 0.5:
                            distance2Leader = abs(
                                best_pos[population[i].skill_factor, j]
                                - population[i].rnvec[j]
                            )
                            Other_distance = abs(
                                best_pos[1 - population[i].skill_factor, j]
                                - population[j1_rand].rnvec[j]
                            )
                            population[i].rnvec[j] = (
                                (distance2Leader + Other_distance) / 2
                                * np.exp(b * l)
                                * np.cos(l * 2 * np.pi)
                                + best_pos[population[i].skill_factor, j]
                            )
                else:
                    for j in range(D_multitask):
                        if p < 0.5:
                            if abs(A) >= 1:
                                D_X_rand = abs(C * population[i_rand].rnvec[j] - population[i].rnvec[j])
                                population[i].rnvec[j] = (
                                    population[i_rand].rnvec[j] - A * D_X_rand
                                )
                            elif abs(A) < 1:
                                D_Leader = abs(
                                    C * best_pos[population[i].skill_factor, j]
                                    - population[i].rnvec[j]
                                )
                                population[i].rnvec[j] = (
                                    best_pos[population[i].skill_factor, j]
                                    - A * D_Leader
                                )
                        elif p >= 0.5:
                            distance2Leader = abs(
                                best_pos[population[i].skill_factor, j]
                                - population[i].rnvec[j]
                            )
                            population[i].rnvec[j] = (
                                distance2Leader * np.exp(b * l) * np.cos(l * 2 * np.pi)
                                + best_pos[population[i].skill_factor, j]
                            )

                population[i] = boundary_check(population[i], D_multitask)

            for i in range(pop_M):
                population[i] = evaluate(population[i], Tasks, p_il, no_of_tasks, options)
                calls_per_individual[i] = 1

            fnceval_calls[rep] += np.sum(calls_per_individual)
            TotalEvaluations[rep, t] = fnceval_calls[rep]

            factorial_cost = np.zeros(pop_M)
            for i in range(no_of_tasks):
                for j in range(pop_M):
                    factorial_cost[j] = population[j].factorial_costs[i]

                sorted_indices = np.argsort(factorial_cost)
                population = [population[sorted_indices[j]] for j in range(pop_M)]

                for j in range(pop_M):
                    population[j].factorial_ranks[i] = j

                if population[0].factorial_costs[i] <= bestobj[i]:
                    bestobj[i] = population[0].factorial_costs[i]
                    best_pos[i, :] = population[0].rnvec
                    bestInd_data[rep, i] = population[0]

                EvBestFitness[i + 2 * (rep - 1), t + 1] = bestobj[i]

            for i in range(pop_M):
                min_rank_index = np.argmin(population[i].factorial_ranks)
                population[i].skill_factor = min_rank_index
                population[i].scalar_fitness = 1 / (min_rank_index + 1)

            print(
                f'MFWOA iteration = {t}, best factorial costs = {bestobj}, best position = {best_pos}'
            )
            t += 1

    data_MFWOA = {
        'wall_clock_time': time.time() - tic.t,
        'EvBestFitness': EvBestFitness,
        'bestInd_data': bestInd_data,
        'TotalEvaluations': TotalEvaluations,
    }

    # Plotting
    for i in range(no_of_tasks):
        plt.figure(i)
        plt.plot(EvBestFitness[i, :])
        plt.xlabel('GENERATIONS')
        plt.ylabel(f'TASK {i} OBJECTIVE')
        plt.legend(['MFWOA'])
        plt.show()

    return data_MFWOA
