import numpy as np
from scipy.optimize import fminbound
import random

class Chromosome:
    def __init__(self, D):
        self.rnvec = np.zeros(D)
        self.factorial_costs = 0

def WOA(Task, task_for_comparison_with_SOO, pop, gen, p_il, reps):
    def initialize(chromosome, D):
        chromosome.rnvec = np.random.rand(D)
        chromosome.factorial_costs = 0
        return chromosome

    def evaluate_SOO(chromosome, Task, p_il, options):
        result = fminbound(Task.fnc, Task.Lb, Task.Ub, disp=False, maxiter=options['MaxIter'])
        chromosome.factorial_costs = result
        return chromosome

    def boundary_check(chromosome):
        chromosome.rnvec[chromosome.rnvec > 1] = 1
        chromosome.rnvec[chromosome.rnvec < 0] = 0
        return chromosome

    def sort_population(population):
        return sorted(population, key=lambda x: x.factorial_costs)

    clc = lambda: None
    tic = lambda: None
    tic.t = time.time()

    if pop % 2 != 0:
        pop += 1

    D = Task.dims
    options = {'Display': 'off', 'Algorithm': 'quasi-newton', 'MaxIter': 2}

    fnceval_calls = np.zeros(reps)
    calls_per_individual = np.zeros(pop)
    EvBestFitness = np.zeros((reps, gen))
    TotalEvaluations = np.zeros((reps, gen))

    for rep in range(reps):
        print(rep)
        population = [Chromosome(D) for _ in range(pop)]

        Leader_pos = np.zeros(D)
        Leader_score = float('inf')

        for i in range(pop):
            population[i] = initialize(population[i], D)

        for i in range(pop):
            population[i] = evaluate_SOO(population[i], Task, p_il, options)
            calls_per_individual[i] = 1

        fnceval_calls[rep] = np.sum(calls_per_individual)
        TotalEvaluations[rep, 0] = fnceval_calls[rep]

        bestobj, bestId = min([(ind.factorial_costs, i) for i, ind in enumerate(population)])
        Leader_pos = population[bestId].rnvec
        Leader_score = bestobj
        EvBestFitness[rep, 0] = Leader_score

        t = 1
        while t <= gen:
            a = 2 - t * (2 / gen)
            a2 = -1 + t * (-1 / gen)

            for i in range(pop):
                r1, r2 = random.random(), random.random()

                A = 2 * a * r1 - a
                C = 2 * r2

                b = 1
                l = (a2 - 1) * random.random() + 1
                p = random.random()

                rand_leader_index = random.randint(0, pop - 1)
                X_rand = population[rand_leader_index].rnvec

                for j in range(D):
                    if p < 0.5:
                        if abs(A) >= 1:
                            D_X_rand = abs(C * X_rand[j] - population[i].rnvec[j])
                            population[i].rnvec[j] = X_rand[j] - A * D_X_rand
                        elif abs(A) < 1:
                            D_Leader = abs(C * Leader_pos[j] - population[i].rnvec[j])
                            population[i].rnvec[j] = Leader_pos[j] - A * D_Leader
                    elif p >= 0.5:
                        distance2Leader = abs(Leader_pos[j] - population[i].rnvec[j])
                        population[i].rnvec[j] = (
                            distance2Leader * np.exp(b * l) * np.cos(l * 2 * np.pi) + Leader_pos[j]
                        )

                population[i] = boundary_check(population[i])

            for i in range(pop):
                population[i] = evaluate_SOO(population[i], Task, p_il, options)
                calls_per_individual[i] = 1

            fnceval_calls[rep] += np.sum(calls_per_individual)
            TotalEvaluations[rep, t] = fnceval_calls[rep]

            population = sort_population(population)

            if population[0].factorial_costs <= Leader_score:
                Leader_score = population[0].factorial_costs
                Leader_pos = population[0].rnvec

            EvBestFitness[rep, t] = Leader_score

            print(f'WOA iteration = {t}, best factorial costs = {Leader_score}')
            t += 1

    data_SOO = {'wall_clock_time': time.time() - tic.t,
                'EvBestFitness': EvBestFitness,
                'TotalEvaluations': TotalEvaluations}

    # Plotting
    plt.figure(task_for_comparison_with_SOO)
    plt.plot(EvBestFitness)
    plt.xlabel('GENERATIONS')
    plt.ylabel(f'TASK {task_for_comparison_with_SOO} OBJECTIVE')
    plt.legend(['MFWOA', 'WOA'])
    plt.show()

    return data_SOO
