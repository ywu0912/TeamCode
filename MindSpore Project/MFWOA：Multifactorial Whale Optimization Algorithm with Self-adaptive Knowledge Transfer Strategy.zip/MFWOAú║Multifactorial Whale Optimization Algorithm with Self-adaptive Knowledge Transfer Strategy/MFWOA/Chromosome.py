import numpy as np

class Chromosome:
    def __init__(self, D):
        self.rnvec = np.zeros(D)
        self.factorial_costs = np.zeros(D)
        self.factorial_ranks = np.zeros(D)
        self.scalar_fitness = 0
        self.skill_factor = 0

    def initialize(self, D):
        self.rnvec = np.random.rand(D)

    def evaluate(self, Tasks, p_il, no_of_tasks, options):
        calls = 0
        if self.skill_factor == 0:
            for i in range(no_of_tasks):
                self.factorial_costs[i], _, funcCount = fnceval(Tasks[i], self.rnvec, p_il, options)
                calls += funcCount
        else:
            self.factorial_costs[0:no_of_tasks] = np.inf
            for i in range(no_of_tasks):
                if self.skill_factor == i + 1:
                    self.factorial_costs[self.skill_factor - 1], self.rnvec, funcCount = fnceval(
                        Tasks[self.skill_factor - 1], self.rnvec, p_il, options
                    )
                    calls = funcCount
                    break
        return self, calls

    def evaluate_SOO(self, Task, p_il, options):
        self.factorial_costs, self.rnvec, funcCount = fnceval(Task, self.rnvec, p_il, options)
        return self, funcCount
